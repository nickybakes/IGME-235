function clamp(val, min, max) {
    return val < min ? min : (val > max ? max : val);
}

//interpolate a value between 2 points
function lerp(start, end, amt) {
    return start * (1 - amt) + amt * end;
}

function lerpClamped(start, end, amt) {
    return start * (1 - clamp(amt, 0, 1)) + clamp(amt, 0, 1) * end;
}

//takes bilinear coods UV, and interps between 4 values
function bilinearInterp(uv, a, b, c, d) {
    return lerp(lerp(d, a, uv.y), lerp(c, b, uv.y), uv.x);
}

function moveIntoRange(val, min, max) {
    let diff = max - min;
    while (val < min) {
        val += diff;
    }
    while (val >= max) {
        val -= diff;
    }
    return val;
}

//converts degrees to radians
function rad(deg) {
    return deg * Math.PI / 180;
}

//converts radians to degrees
function deg(rad) {
    return rad * 180 / Math.PI;
}

// function areaOfTriangle(ax, ay, bx, by, cx, cy){
//     return Math.abs((ax*(by-cy) + bx*(cy - ay) + cx*(ay - by))/2);
//     // return ((ax - cx) * (by - cy) - (bx - cx) * (ay - cy))/2;
// }

function areaOfTriangle(a, b, c) {
    return Math.abs((a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y)) / 2);
    // return ((ax - cx) * (by - cy) - (bx - cx) * (ay - cy))/2;
}

function dist(x1, y1, x2, y2) {
    return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
}

function distSquared(x1, y1, x2, y2) {
    return Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2);
}

function average(a, b) {
    return (a + b) / 2;
}

function secondsToTimeString(seconds){
    //clamp to 99 minutes and 59 seconds
    seconds = clamp(seconds, 0, 5549.999);
    //use javascript date to parse our seconds value as time
    let date = new Date(null);
    date.setSeconds(seconds, (seconds - parseInt(seconds))*1000);
    //limit it to just the minutes, seconds, and milliseconds
    let timeString = date.toISOString().substr(14, 8);
    //return the result
    return timeString;
}