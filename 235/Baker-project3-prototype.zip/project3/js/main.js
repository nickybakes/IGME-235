"use strict";
const app = new PIXI.Application({
    width: 1024,
    height: 576
});
document.body.appendChild(app.view);

//resolution of the entire canvas area
const sceneWidth = app.view.width;
const sceneHeight = app.view.height;

//resolution that i want my 3d graphics to be displayed at
const inGameResWidth = 96;
const inGameResHeight = 54;

//the scale of a 'pixel' in our 3d view.
const resScale = sceneWidth / inGameResWidth;

//arrays of pixel colors and depth values for our 3d view
let renderBuffer = [];
let depthBuffer = [];

//the pixi graphics object we are drawing our 3d render to
let render;

//objects that are involved with projecting 3d points to the scene and filling in triangles with specific colors
let rasterizer;
let camera;

let stage;
let titleScene;
let howToPlayScene;
let customizeCarScene;
let trackPreviewScene;
let raceScene;
let pauseScene;
let resultsScene;
let scenes = [];

let gameState = 0;
//0 - title screen;
//1 - how to play
//2 - car customization
//3 - track preview
//4 - racing/gameplay
//5 - paused
//6 - results/gameover

let displayTrackMesh;
let displayCarModel;
let displayTrackModel;

let trackMesh;
let trackBumperMesh;
let trackFinishLineMesh;
let trackBoostPadsMesh;
let trackModel;
let trackBumperModel;
let trackFinishLineModel;
let trackBoostPadsModel;

let previewingTrack = true;

let mapWidth;
let mapLength;
let mapHeight;
let randomPoints = [];
let convexHull = [];
let trackPoints = [];
let boostPads = [];
let raceTrack;
let heightMap;
let highlightCycleTimer = 0;

let carMesh;
let playerCarColor = new Color(255, 217, 0);

//Key names for local storage
const prefix = "nmb9745-";
const carColorKey = prefix + "carColor";

let playerCar;

let mousePosition;
let keysHeld = [];
let keysReleased = [];

let bgEvening;
let bgMenuNear;
let bgMenuFar;
let bgMenuSky;
let bgPosition;
let steeringWheel;
let buttonStyle;
let buttonStyleSmall;
let countDownStyle;
let hudLabelStyleYellow;
let hudLabelStyleYellowSmall;
let hudLabelStyleWhite;
let customizeCarRedLabel;
let customizeCarGreenLabel;
let customizeCarBlueLabel;
let redTrackBar;
let greenTrackBar;
let blueTrackBar;

let countDownLabel;
let lapAlertLabel;
let wrongWayAlertLabel;
let lapCountLabel;
let timeLabel;
let speedLabel;
let resultsLapTimeLabels;
let resultsLapNumberLabels;
let resultsTotalTimeLabel;

app.loader
    .add("bgEvening", "media/bg-evening.jpg")
    .add("bgMenuNear", "media/evening-near.png")
    .add("bgMenuFar", "media/evening-far.png")
    .add("bgMenuSky", "media/evening-sky.png")
    .add("steeringWheel", "media/steering-wheel.png")
    .add("logo", "media/urban-underdog-logo.png")
    .add("howToPlay", "media/how-to-play.png")
    .add("screenDarken", "media/screen-darken.png");

app.loader.onComplete.add(setUpGame);
app.loader.load();

function setUpGame() {
    window.addEventListener("keydown", keysDown);
    window.addEventListener("keyup", keysUp);

    //set up our scenes/containers
    stage = app.stage;

    titleScene = new PIXI.Container();
    howToPlayScene = new PIXI.Container();
    customizeCarScene = new PIXI.Container();
    trackPreviewScene = new PIXI.Container();
    raceScene = new PIXI.Container();
    pauseScene = new PIXI.Container();
    resultsScene = new PIXI.Container();

    bgEvening = createBg(app.loader.resources["bgEvening"].texture, stage);

    bgMenuSky = createBg(app.loader.resources["bgMenuSky"].texture, stage);
    bgMenuFar = createBg(app.loader.resources["bgMenuFar"].texture, stage);
    bgMenuNear = createBg(app.loader.resources["bgMenuNear"].texture, stage);


    //this renderer is how we will draw individual pixels onto screen
    render = new PIXI.Graphics();
    render.interactiveChildren = false
    stage.addChild(render);


    stage.addChild(titleScene);
    stage.addChild(howToPlayScene);
    stage.addChild(customizeCarScene);
    stage.addChild(trackPreviewScene);
    stage.addChild(raceScene);
    stage.addChild(pauseScene);
    stage.addChild(resultsScene);

    scenes = [titleScene, howToPlayScene, customizeCarScene, trackPreviewScene, raceScene, pauseScene, resultsScene];



    //add our HUD elements in front of the render
    buildHUD();


    //objects needed to project and rasterize 3D graphics
    camera = new Camera(0, -60, -140, -25);
    rasterizer = new Rasterizer(camera);

    loadCarColor();

    //build meshes/models we will need
    buildCarMesh();
    buildDisplayTrackMesh();
    displayCarModel = new Model(0, 4, 7, 0, 0, 0, 2, 2, 2, carMesh);
    displayTrackModel = new Model(10, 4, 4, 0, 0, 0, 1, 1, 2, displayTrackMesh);

    //our game state starts at 0 (title screen)
    setGameState(0);


    //reset our rendering objects
    render.clear();
    clearRenderBuffer();
    clearDepthBuffer();

    app.ticker.add(updateLoop);
}

function setGameState(state) {
    gameState = state;
    for (let i = 0; i < scenes.length; i++) {
        scenes[i].visible = false;
    }
    scenes[state].visible = true;

    if (state == 3 && (raceTrack == null || raceTrack == undefined)) {
        generateTrack();
    }
    if (state == 4 || state == 5 || state == 6) {
        bgMenuNear.visible = false;
        bgMenuFar.visible = false;
        bgMenuSky.visible = false;
    } else {
        bgMenuNear.visible = true;
        bgMenuFar.visible = true;
        bgMenuSky.visible = true;
    }
}

function loadCarColor() {
    let loadedCarColorString = localStorage.getItem(carColorKey);
    let loadedCarColor = JSON.parse(loadedCarColorString);
    if (loadedCarColor) {
        playerCarColor = new Color(loadedCarColor.red, loadedCarColor.green, loadedCarColor.blue);
    }
    else {
        playerCarColor = new Color(255, 217, 0);
    }
    redTrackBar.setValue(playerCarColor.red / 255);
    greenTrackBar.setValue(playerCarColor.green / 255);
    blueTrackBar.setValue(playerCarColor.blue / 255);
    setCarColorRed();
    setCarColorGreen();
    setCarColorBlue();
}

function saveCarColor() {
    let playerCarColorStringified = JSON.stringify(playerCarColor);
    localStorage.setItem(carColorKey, playerCarColorStringified);
}

function buildHUD() {
    titleScene.addChild(new PIXI.Sprite.from(app.loader.resources["logo"].texture))


    buttonStyle = new PIXI.TextStyle({
        fill: 0xFFFF00,
        fontSize: 48,
        fontFamily: "Goldman",
        fontWeight: 'bold',
        stroke: 0x00000,
        strokeThickness: 8
    });

    buttonStyleSmall = new PIXI.TextStyle({
        fill: 0xFFFF00,
        fontSize: 36,
        fontFamily: "Goldman",
        fontWeight: 'bold',
        stroke: 0x000000,
        strokeThickness: 8
    });

    countDownStyle = new PIXI.TextStyle({
        fill: 0xFFFF00,
        fontSize: 106,
        fontFamily: "Goldman",
        fontWeight: 'bold',
        stroke: 0x000000,
        strokeThickness: 12
    });

    hudLabelStyleYellowSmall = new PIXI.TextStyle({
        fill: 0xFFFF00,
        fontSize: 24,
        fontFamily: "Goldman",
        fontWeight: 'bold',
        stroke: 0x000000,
        strokeThickness: 8
    });

    hudLabelStyleYellow = new PIXI.TextStyle({
        fill: 0xFFFF00,
        fontSize: 42,
        fontFamily: "Goldman",
        fontWeight: 'bold',
        stroke: 0x000000,
        strokeThickness: 8
    });


    hudLabelStyleWhite = new PIXI.TextStyle({
        fill: 0xFFFFFF,
        fontSize: 42,
        fontFamily: "Goldman",
        fontWeight: 'bold',
        stroke: 0x000000,
        strokeThickness: 8
    });

    //finally, make the start game button
    titleScene.addChild(createButton("Start Your Engine!", sceneWidth / 2, 300, function () { setGameState(1); }));

    howToPlayScene.addChild(new PIXI.Sprite.from(app.loader.resources["howToPlay"].texture));
    howToPlayScene.addChild(createButton("Next", 800, 460, function () { setGameState(2); }));
    howToPlayScene.addChild(createButton("Back", 220, 460, function () { setGameState(0); }));

    let titleTextStyle = new PIXI.TextStyle({
        fill: 0xFFFFFF,
        fontSize: 72,
        fontFamily: "Goldman",
        fontWeight: 'bold',
        fontStyle: 'italic',
    });

    let sliderTextRed = new PIXI.TextStyle({
        fill: 0xFF0000,
        fontSize: 36,
        fontFamily: "Goldman",
        fontWeight: 'bold',
        fontStyle: 'italic',
        stroke: 0x00000,
        strokeThickness: 7
    });

    let sliderTextGreen = new PIXI.TextStyle({
        fill: 0x00FF00,
        fontSize: 36,
        fontFamily: "Goldman",
        fontWeight: 'bold',
        fontStyle: 'italic',
        stroke: 0x00000,
        strokeThickness: 7
    });

    let sliderTextBlue = new PIXI.TextStyle({
        fill: 0x0000FF,
        fontSize: 36,
        fontFamily: "Goldman",
        fontWeight: 'bold',
        fontStyle: 'italic',
        stroke: 0x00000,
        strokeThickness: 7
    });

    let customizeCarTitle = new PIXI.Text(" Customize Car Color! ");
    customizeCarTitle.style = titleTextStyle;
    customizeCarTitle.x = sceneWidth / 2;
    customizeCarTitle.y = 60;
    customizeCarTitle.anchor.set(.5);

    customizeCarRedLabel = new PIXI.Text(" Red ");
    customizeCarRedLabel.style = sliderTextRed;
    customizeCarRedLabel.x = 100;
    customizeCarRedLabel.y = 130;

    customizeCarGreenLabel = new PIXI.Text(" Green ");
    customizeCarGreenLabel.style = sliderTextGreen;
    customizeCarGreenLabel.x = 100;
    customizeCarGreenLabel.y = 230;

    customizeCarBlueLabel = new PIXI.Text(" Blue ");
    customizeCarBlueLabel.style = sliderTextBlue;
    customizeCarBlueLabel.x = 100;
    customizeCarBlueLabel.y = 330;

    redTrackBar = new TrackBar(60, 100, 360, 12, 0xFF0000, setCarColorRed, saveCarColor);
    greenTrackBar = new TrackBar(60, 150, 360, 12, 0x00FF00, setCarColorGreen, saveCarColor);
    blueTrackBar = new TrackBar(60, 200, 360, 12, 0x0000FF, setCarColorBlue, saveCarColor);


    customizeCarScene.addChild(customizeCarTitle);
    customizeCarScene.addChild(customizeCarRedLabel);
    customizeCarScene.addChild(customizeCarGreenLabel);
    customizeCarScene.addChild(customizeCarBlueLabel);
    customizeCarScene.addChild(createButton("Done", 820, 480, function () { setGameState(3); }, buttonStyle));
    customizeCarScene.addChild(createButton("Back", 200, 480, function () { setGameState(1); }, buttonStyleSmall));
    customizeCarScene.addChild(redTrackBar);
    customizeCarScene.addChild(greenTrackBar);
    customizeCarScene.addChild(blueTrackBar);


    trackPreviewScene.addChild(createButton("Play", 900, 50, function () { startRace(); }, buttonStyle));
    trackPreviewScene.addChild(createButton("Regenerate", sceneWidth / 2, 50, function () { generateTrack(); }, buttonStyleSmall));
    trackPreviewScene.addChild(createButton("Back", 100, 50, function () { setGameState(2); }, buttonStyleSmall));
    trackPreviewScene.addChild(createButton("Copy Track\n        Code", 150, 480, function () {copyTrackCode(); }, buttonStyleSmall));
    trackPreviewScene.addChild(createButton("Input Track\n from Code", 870, 480, function () {loadTrackCode(); }, buttonStyleSmall));


    pauseScene.addChild(new PIXI.Sprite.from(app.loader.resources["screenDarken"].texture));
    let pausedTitle = new PIXI.Text(" Paused! ");
    pausedTitle.style = titleTextStyle;
    pausedTitle.x = sceneWidth / 2;
    pausedTitle.y = 120;
    pausedTitle.anchor.set(.5);
    pauseScene.addChild(pausedTitle);
    pauseScene.addChild(createButton("Resume", sceneWidth / 2, 260, function () { setGameState(4); }));
    pauseScene.addChild(createButton("Restart", sceneWidth / 2, 320, function () { startRace(); }));
    pauseScene.addChild(createButton("Quit to Menu", sceneWidth / 2, 380, function () { setGameState(3); }));

    countDownLabel = new PIXI.Text("3");
    countDownLabel.style = countDownStyle;
    countDownLabel.x = sceneWidth / 2;
    countDownLabel.y = sceneHeight / 2;
    countDownLabel.anchor.set(.5);

    lapAlertLabel = new PIXI.Text("");
    lapAlertLabel.style = countDownStyle;
    lapAlertLabel.x = sceneWidth / 2;
    lapAlertLabel.y = sceneHeight / 2 + 70;
    lapAlertLabel.anchor.set(.5);

    wrongWayAlertLabel = new PIXI.Text("");
    wrongWayAlertLabel.style = countDownStyle;
    wrongWayAlertLabel.x = sceneWidth / 2;
    wrongWayAlertLabel.y = sceneHeight / 2 - 100;
    wrongWayAlertLabel.anchor.set(.5);

    lapCountLabel = new PIXI.Text("");
    lapCountLabel.style = hudLabelStyleYellow;
    lapCountLabel.x = 900;
    lapCountLabel.y = sceneHeight - 50;
    lapCountLabel.anchor.set(.5);

    timeLabel = new PIXI.Text("");
    timeLabel.style = hudLabelStyleYellow;
    timeLabel.x = 60;
    timeLabel.y = sceneHeight - 100;

    speedLabel = new PIXI.Text("");
    speedLabel.style = hudLabelStyleYellow;
    speedLabel.x = 900;
    speedLabel.y = sceneHeight - 100;
    speedLabel.anchor.set(.5);

    raceScene.addChild(lapAlertLabel);
    raceScene.addChild(wrongWayAlertLabel);
    raceScene.addChild(countDownLabel);
    raceScene.addChild(lapCountLabel);
    raceScene.addChild(timeLabel);
    raceScene.addChild(speedLabel);

    resultsScene.addChild(new PIXI.Sprite.from(app.loader.resources["screenDarken"].texture));
    let resultsTitle = new PIXI.Text(" Nice Driving! ");
    resultsTitle.style = titleTextStyle;
    resultsTitle.x = sceneWidth / 2;
    resultsTitle.y = 50;
    resultsTitle.anchor.set(.5);
    resultsScene.addChild(resultsTitle);
    resultsScene.addChild(createButton("   Play\n Again", 820, 440, function () { startRace(); }));
    resultsScene.addChild(createButton("Quit to\n  Menu", 200, 440, function () { setGameState(3); }));

    resultsLapTimeLabels = [];
    resultsLapNumberLabels = [];

    for(let i = 0; i < 5; i++){
        let lapNumberLabel = new PIXI.Text("LAP " + (i+1));
        lapNumberLabel.style = hudLabelStyleWhite;
        lapNumberLabel.x = sceneWidth/2 - 90;
        lapNumberLabel.y = 120 + 40*i;
        lapNumberLabel.anchor.set(1, .5);
        resultsLapNumberLabels.push(lapNumberLabel);
        resultsScene.addChild(lapNumberLabel);

        let lapTimeLabel = new PIXI.Text("");
        lapTimeLabel.style = hudLabelStyleWhite;
        lapTimeLabel.x = sceneWidth/2 + 15;
        lapTimeLabel.y = 120 + 40*i;
        lapTimeLabel.anchor.set(0, .5);
        resultsLapTimeLabels.push(lapTimeLabel);
        resultsScene.addChild(lapTimeLabel);
    }

    let resultsTotalLabel = new PIXI.Text("TOTAL");
    resultsTotalLabel.style = hudLabelStyleWhite;
    resultsTotalLabel.x = sceneWidth/2 - 90;
    resultsTotalLabel.y = 340;
    resultsTotalLabel.anchor.set(1, .5);
    resultsLapNumberLabels.push(resultsTotalLabel);
    resultsScene.addChild(resultsTotalLabel);

    resultsTotalTimeLabel = new PIXI.Text("");
    resultsTotalTimeLabel.style = hudLabelStyleWhite;
    resultsTotalTimeLabel.x = sceneWidth/2 + 15;
    resultsTotalTimeLabel.y = 340;
    resultsTotalTimeLabel.anchor.set(0, .5);
    resultsScene.addChild(resultsTotalTimeLabel);

    steeringWheel = new SteeringWheel(512, 596);
    stage.addChild(steeringWheel);
}

function copyTrackCode(){
    if(raceTrack == null || raceTrack == undefined){
        return;
    }

    let shareableTrackPoints = [];

    for(let i = 0; i < trackPoints.length; i++){
        shareableTrackPoints.push({
            a: trackPoints[i].pos,
            b: trackPoints[i].outsidePoint
        });
    }

    let trackCodeString = JSON.stringify(shareableTrackPoints);
    //creates an area of text in the document
    const codeArea = document.createElement('textarea');
    //makes its value our url link
    codeArea.value = trackCodeString;
    //add it to the doc and select it
    document.body.appendChild(codeArea);
    codeArea.select();
    //copy the selected region to the clipboard, then remove it from our doc
    document.execCommand("copy");
    document.body.removeChild(codeArea);

    showMessage("COPIED!");
}

function loadTrackCode(){
    let trackCode = document.querySelector("#track-code-input").value;
    if (trackCode.length < 1) {
        showMessage("Invalid track code!");
        return;
    }

    let inputtedTrackPoints = JSON.parse(trackCode);

    trackPoints = [];
    highlightCycleTimer = 0;
    raceTrack = new RaceTrack();

    for(let i = 0; i < inputtedTrackPoints.length; i++){
        let point = new TrackPoint();
        let pos = new Vector3(inputtedTrackPoints[i].a.x, inputtedTrackPoints[i].a.y, inputtedTrackPoints[i].a.z);
        point.pos = pos;
        let outsidePoint = new Vector3(inputtedTrackPoints[i].b.x, inputtedTrackPoints[i].b.y, inputtedTrackPoints[i].b.z);
        point.outsidePoint = outsidePoint;
        trackPoints.push(point);
    }

    linkTrackPoints();
    buildTrackMesh();
    trackModel = new Model(0, 0, 0, 0, 0, 0, .0625, .25, .0625, trackMesh);
    trackBumperModel = new Model(0, 0, 0, 0, 0, 0, .0625, .25, .0625, trackBumperMesh);
    trackFinishLineModel = new Model(0, 0, 0, 0, 0, 0, .0625, .25, .0625, trackFinishLineMesh);
}

//shows our message box and then hides it after a second
function showMessage(message) {
    //get our message box
    let messageBox = document.querySelector(".message");
    //set its text to our custom message
    messageBox.innerHTML = message;

    //show the message box!
    messageBox.style.opacity = 1;
    messageBox.style.visibility = "visible";
    messageBox.style.transform = "scaleY(1)";

    //after about a second, hide the message box again
    setTimeout(hideMessage, 1300);
}

//hides our message box
function hideMessage() {
    //get our message box and hide it
    let messageBox = document.querySelector(".message");
    messageBox.style.opacity = 0;
    messageBox.style.visibility = "hidden";
    messageBox.style.transform = "scaleY(0)";
}

function setCarColorRed() {
    let value = parseInt(255 * redTrackBar.value);
    customizeCarRedLabel.text = " Red - " + value + " ";
    playerCarColor.red = value;
}

function setCarColorGreen() {
    let value = parseInt(255 * greenTrackBar.value);
    customizeCarGreenLabel.text = " Green - " + value + " ";
    playerCarColor.green = value;
}

function setCarColorBlue() {
    let value = parseInt(255 * blueTrackBar.value);
    customizeCarBlueLabel.text = " Blue - " + value + " ";
    playerCarColor.blue = value;
}

function createButton(text, x, y, func, style = buttonStyle) {
    let button = new PIXI.Text(text);
    button.style = style;
    button.x = x;
    button.y = y;
    button.anchor.set(.5, .5);
    button.interactive = true;
    button.buttonMode = true;
    button.on('pointerup', func);
    button.on('pointerover', e => e.target.alpha = 0.7);
    button.on('pointerout', e => e.currentTarget.alpha = 1.0);
    return button;
}

function buildDisplayTrackMesh() {
    displayTrackMesh = new Mesh();
    //concrete base
    displayTrackMesh.convertQuadToTrisAndAddThem(new Vector3(-100, 0, 20), new Vector3(100, 0, 40), new Vector3(100, 0, -50), new Vector3(-100, 0, -50), new Color(70, 70, 70));

    //railings
    displayTrackMesh.convertQuadToTrisAndAddThem(new Vector3(-100, -8, 20), new Vector3(-50, -8, 25), new Vector3(-50, 0, 25), new Vector3(-100, 0, 20), Color.WHITE());
    displayTrackMesh.convertQuadToTrisAndAddThem(new Vector3(-50, -8, 25), new Vector3(0, -8, 30), new Vector3(0, 0, 30), new Vector3(-50, 0, 25), Color.RED());
    displayTrackMesh.convertQuadToTrisAndAddThem(new Vector3(0, -8, 30), new Vector3(50, -8, 35), new Vector3(50, 0, 35), new Vector3(0, 0, 30), Color.WHITE());
    displayTrackMesh.convertQuadToTrisAndAddThem(new Vector3(50, -8, 35), new Vector3(100, -8, 40), new Vector3(100, 0, 40), new Vector3(50, 0, 35), Color.RED());
}

function buildCarMesh() {
    //build our car mesh
    carMesh = new Mesh();
    //left side bottom
    carMesh.convertQuadToTrisAndAddThem(new Vector3(-5, -4, 8), new Vector3(-5, -5, -12), new Vector3(-5, -.5, -8), new Vector3(-5, 0, 10), playerCarColor);
    //back bottom
    carMesh.convertQuadToTrisAndAddThem(new Vector3(-5, -5, -12), new Vector3(5, -5, -12), new Vector3(5, -.5, -8), new Vector3(-5, -.5, -8), playerCarColor);
    //right bottom
    carMesh.convertQuadToTrisAndAddThem(new Vector3(5, -5, -12), new Vector3(5, -4, 8), new Vector3(5, 0, 10), new Vector3(5, -.5, -8), playerCarColor);
    //front bottom
    carMesh.convertQuadToTrisAndAddThem(new Vector3(5, -4, 8), new Vector3(-5, -4, 8), new Vector3(-5, 0, 10), new Vector3(5, 0, 10), playerCarColor);

    // //left side mid
    // carMesh.convertQuadToTrisAndAddThem(new Vector3(-4, -5, 4), new Vector3(-4, -5, -6), new Vector3(-5, -5, -12), new Vector3(-5, -4, 8), playerCarColor);
    // //back mid
    // carMesh.convertQuadToTrisAndAddThem(new Vector3(-4, -5, -6), new Vector3(4, -5, -6), new Vector3(5, -5, -12), new Vector3(-5, -5, -12), playerCarColor);
    // //right mid
    // carMesh.convertQuadToTrisAndAddThem(new Vector3(4, -5, -6), new Vector3(4, -5, 4), new Vector3(5, -4, 8), new Vector3(5, -5, -12), playerCarColor);
    // //front mid
    // carMesh.convertQuadToTrisAndAddThem(new Vector3(4, -5, 4), new Vector3(-4, -5, 4), new Vector3(-5, -4, 8), new Vector3(5, -4, 8), playerCarColor);

    carMesh.convertQuadToTrisAndAddThem(new Vector3(-5, -4, 8), new Vector3(5, -4, 8), new Vector3(5, -5, -12), new Vector3(-5, -5, -12), playerCarColor);

    //left side top
    carMesh.convertQuadToTrisAndAddThem(new Vector3(-3, -8, 3), new Vector3(-3, -7, -4), new Vector3(-4, -4, -6), new Vector3(-4, -4, 4), playerCarColor);
    //back top
    carMesh.convertQuadToTrisAndAddThem(new Vector3(-3, -7, -4), new Vector3(3, -7, -4), new Vector3(4, -4, -6), new Vector3(-4, -4, -6), playerCarColor);
    //right top
    carMesh.convertQuadToTrisAndAddThem(new Vector3(3, -7, -4), new Vector3(3, -8, 3), new Vector3(4, -4, 4), new Vector3(4, -4, -6), playerCarColor);
    //front top
    carMesh.convertQuadToTrisAndAddThem(new Vector3(3, -8, 3), new Vector3(-3, -8, 3), new Vector3(-4, -4, 4), new Vector3(4, -4, 4), playerCarColor);

    //top top
    carMesh.convertQuadToTrisAndAddThem(new Vector3(-3, -8, 3), new Vector3(3, -8, 3), new Vector3(3, -7, -4), new Vector3(-3, -7, -4), playerCarColor);

    //left front wheel
    carMesh.convertQuadToTrisAndAddThem(new Vector3(-5.2, -3, 8), new Vector3(-5.2, -3, 4), new Vector3(-5.2, 1, 4), new Vector3(-5.2, 1, 8), new Color(25, 25, 25));
    //left back wheel
    carMesh.convertQuadToTrisAndAddThem(new Vector3(-5.2, -3, -3), new Vector3(-5.2, -3, -7), new Vector3(-5.2, 1, -7), new Vector3(-5.2, 1, -3), new Color(25, 25, 25));
    //right front wheel
    carMesh.convertQuadToTrisAndAddThem(new Vector3(5.2, -3, 4), new Vector3(5.2, -3, 8), new Vector3(5.2, 1, 8), new Vector3(5.2, 1, 4), new Color(25, 25, 25));
    //right back wheel
    carMesh.convertQuadToTrisAndAddThem(new Vector3(5.2, -3, -7), new Vector3(5.2, -3, -3), new Vector3(5.2, 1, -3), new Vector3(5.2, 1, -7), new Color(25, 25, 25));

    //windows on car
    //left side window
    carMesh.convertQuadToTrisAndAddThem(new Vector3(-3.5, -7, 2), new Vector3(-3.5, -6, -3), new Vector3(-4.5, -5.5, -5), new Vector3(-4.5, -5.5, 3), new Color(87, 81, 99));
    //back window
    carMesh.convertQuadToTrisAndAddThem(new Vector3(-2, -6.5, -4.5), new Vector3(2, -6.5, -4.5), new Vector3(3, -5.5, -6.5), new Vector3(-3, -5.5, -6.5), new Color(87, 81, 99));
    //right window
    carMesh.convertQuadToTrisAndAddThem(new Vector3(3.5, -6, -3), new Vector3(3.5, -7, 2), new Vector3(4.5, -5.5, 3), new Vector3(4.5, -5.5, -5), new Color(87, 81, 99));
    //front window
    carMesh.convertQuadToTrisAndAddThem(new Vector3(2, -7.5, 3.5), new Vector3(-2, -7.5, 3.5), new Vector3(-3, -5.5, 4.5), new Vector3(3, -5.5, 4.5), new Color(87, 81, 99));


    //front grill and back lights
    //back left light
    carMesh.convertQuadToTrisAndAddThem(new Vector3(-4, -4, -11.5), new Vector3(-2, -4, -11.5), new Vector3(-2, -3, -10.5), new Vector3(-4, -3, -10.5), new Color(200, 200, 200));
    //back right light
    carMesh.convertQuadToTrisAndAddThem(new Vector3(2, -4, -11.5), new Vector3(4, -4, -11.5), new Vector3(4, -3, -10.5), new Vector3(2, -3, -10.5), new Color(200, 200, 200));
    //front grill
    carMesh.convertQuadToTrisAndAddThem(new Vector3(3.1, -3, 9.1), new Vector3(-3.1, -3, 9.1), new Vector3(-3.1, -1.5, 10.1), new Vector3(3.1, -1.5, 10.1), new Color(45, 45, 45));
}

function generateTrack() {
    mapWidth = 1300 + 128 * (Math.random() - .5);
    mapLength = 1300 + 128 * (Math.random() - .5);
    mapHeight = 200 + 100 * (Math.random() - .5);

    randomPoints = [];
    convexHull = [];
    trackPoints = [];
    boostPads = [];
    highlightCycleTimer = 0;

    raceTrack = new RaceTrack();

    heightMap = new HeightMap();

    //1. place random points in a space 0 to 1
    placeRandomPoints();

    //drawRandomPoints();

    buildConvexHull();

    for (let i = 0; i < 10; i++) {
        addIndents();
    }

    for (let i = 0; i < 3; i++) {
        pushPointsAway();
    }

    // for(let i = 0; i < 6; i++){
    //     smoothTrackMesh();
    // }

    scaleConvexHull();

    //drawConvexHull();


    buildTrackPoints();

    linkTrackPoints();

    extrudePoints();

    buildTrackMesh();

    trackModel = new Model(0, 0, 0, 0, 0, 0, .0625, .25, .0625, trackMesh);
    trackBumperModel = new Model(0, 0, 0, 0, 0, 0, .0625, .25, .0625, trackBumperMesh);
    trackFinishLineModel = new Model(0, 0, 0, 0, 0, 0, .0625, .25, .0625, trackFinishLineMesh);
}

function placeRandomPoints() {
    let numOfPoints = 50 + 15 * (Math.random() - .5);
    for (let i = 0; i < numOfPoints; i++) {
        randomPoints.push(new Vector2(Math.random(), Math.random()));
    }
}

function drawRandomPoints() {
    for (let p of randomPoints) {
        render.beginFill(Color.RED().toHex(), 1);
        render.drawRect(p.x * sceneWidth, p.y * sceneHeight, 5, 5);
    }
}

function buildConvexHull() {
    //find the right most point (point with largest x)
    let rightMostPoint = randomPoints[0];
    for (let p of randomPoints) {
        if (p.x > rightMostPoint.x)
            rightMostPoint = p;
    }

    let a = rightMostPoint;
    convexHull = [];
    //our hull starts with our rightmost point (a)
    convexHull.push(a);
    //then we want to loop through all the points and use Jarvis March algorithm
    //this means we check to see if a point is going in a CCW direction. if so, it should be considered for our convex hull
    do {
        let b = randomPoints[0];
        for (let c of randomPoints) {
            if (c.x == a.x && c.y == a.y)
                continue;
            let crossProduct = Vector2.cross3(a, b, c);
            if (crossProduct >= 0) {
                b = c;
            }
        }

        if (b != a) {
            convexHull.push(b);
            a = b;
        }
        //we break out of the while loop if we loop back to the start point
    } while (a != rightMostPoint);

    convexHull.pop();
}

function drawConvexHull() {
    for (let p of convexHull) {
        render.beginFill(Color.GREEN().toHex(), 1);
        render.drawRect(p.x * sceneWidth, p.y * sceneHeight, 5, 5);
    }

    render.beginFill(Color.WHITE().toHex(), 1);
    render.drawRect(convexHull[0].x * sceneWidth, convexHull[0].y * sceneHeight, 5, 5);
}

function scaleConvexHull() {
    for (let i = 0; i < convexHull.length; i++) {
        convexHull[i] = new Vector2(convexHull[i].x * mapWidth - (mapWidth / 2), mapLength - convexHull[i].y * mapLength - (mapLength / 2));
    }
}

function pushPointsAway() {
    let distance = .15;
    for (let i = 0; i < convexHull.length; i++) {
        for (let j = i + 1; j < convexHull.length; j++) {
            if (Vector2.dist(convexHull[i], convexHull[j]) < distance) {
                let movementDirection = Vector2.subtract(convexHull[j], convexHull[i]).getNormal();
                convexHull[i] = Vector2.add(convexHull[i], Vector2.multiply(movementDirection, -1 * (distance - Vector2.dist(convexHull[i], convexHull[j]))));
                convexHull[j] = Vector2.add(convexHull[j], Vector2.multiply(movementDirection, distance - Vector2.dist(convexHull[i], convexHull[j])));
            }
        }
    }
}

function addIndents() {
    for (let i = 0; i < convexHull.length; i++) {
        let a, b;
        if (i == convexHull.length - 1) {
            a = convexHull[i];
            b = convexHull[0];
        } else {
            a = convexHull[i];
            b = convexHull[i + 1];
        }
        if (Vector2.dist(a, b) > .25) {
            let c = Vector2.lerp(a, b, .5 + .3 * (Math.random() - .5));
            let normalDirection = Vector2.subtract(b, a).perpCW().getNormal();
            c = Vector2.add(c, Vector2.multiply(normalDirection, .25 * (Math.random() - .5)));
            convexHull.splice(i + 1, 0, c);
        }
    }
}


function smoothTrackMesh() {
    for (let i = 0; i < convexHull.length; i++) {
        let a, b;
        if (i == convexHull.length - 1) {
            a = convexHull[i];
            b = convexHull[0];
        } else {
            a = convexHull[i];
            b = convexHull[i + 1];
        }
        if (Vector2.dist(a, b) > .15) {
            console.log(i);
            let c = Vector2.lerp(a, b, .5);
            convexHull.splice(i + 1, 0, c);
        }
    }
}

function buildTrackPoints() {
    trackPoints = [];
    let widthBase = average(mapWidth, mapLength) / 5;
    let widthVariation = widthBase / (2);
    for (let i = 0; i < convexHull.length; i++) {
        trackPoints.push(new TrackPoint(convexHull[i].x, 0, convexHull[i].y, widthBase + widthVariation * (Math.random() - .5), true));
    }
}

function linkTrackPoints(){
    for (let i = 0; i < trackPoints.length; i++) {
        if (i == 0) {
            trackPoints[0].previousPoint = trackPoints[trackPoints.length - 1];
            trackPoints[0].nextPoint = trackPoints[1];
        }
        else if (i == trackPoints.length - 1) {
            trackPoints[i].previousPoint = trackPoints[trackPoints.length - 2];
            trackPoints[i].nextPoint = trackPoints[0];
        }
        else {
            trackPoints[i].previousPoint = trackPoints[i - 1];
            trackPoints[i].nextPoint = trackPoints[i + 1];
        }
    }
}

function extrudePoints(){
    for(let i = 0; i < trackPoints.length; i++){
        trackPoints[i].getOutsidePoint();
    }
}

function addBoostPads() {

}

function buildTrackMesh() {
    trackMesh = new Mesh();
    trackBumperMesh = new Mesh();
    let trackSegments = [];
    for (let i = 0; i < trackPoints.length; i++) {
        let a = trackPoints[i].nextPoint.pos;
        let b = trackPoints[i].nextPoint.outsidePoint;
        let c = trackPoints[i].outsidePoint;
        let d = trackPoints[i].pos;
        trackMesh.convertQuadToTrisAndAddThem(a, b, c, d, new Color(255 * ((i + 1) / (trackPoints.length)), 255 * ((i + 1) / (trackPoints.length)), 255 * ((i + 1) / (trackPoints.length))))
        trackSegments.push(new TrackSegment(a, b, c, d, trackMesh.tris[trackMesh.tris.length - 2], trackMesh.tris[trackMesh.tris.length - 1], trackPoints[i], trackPoints[i].nextPoint, i));
        let bumperFullInsideA = new Vector3(d.x, d.y - 8, d.z);
        let bumperFullInsideB = new Vector3(a.x, a.y - 8, a.z);
        let numberOfStripes = 4;
        for (let j = 0; j < numberOfStripes; j++) {
            let stripeA = Vector3.lerp(bumperFullInsideA, bumperFullInsideB, j / numberOfStripes);
            let stripeB = Vector3.lerp(bumperFullInsideA, bumperFullInsideB, 1 / numberOfStripes + j / numberOfStripes);
            let stripeC = Vector3.lerp(d, a, 1 / numberOfStripes + j / numberOfStripes);
            let stripeD = Vector3.lerp(d, a, j / numberOfStripes);
            let stripeColor = Color.RED();
            if (j % 2 == 0)
                stripeColor = Color.WHITE();
            trackBumperMesh.convertQuadToTrisAndAddThem(stripeA, stripeB, stripeC, stripeD, stripeColor);
            trackSegments[i].insideBarrierMesh.convertQuadToTrisAndAddThem(stripeA, stripeB, stripeC, stripeD, stripeColor);
        }

        let bumperFullOutsideA = new Vector3(b.x, b.y - 8, b.z);
        let bumperFullOutsideB = new Vector3(c.x, c.y - 8, c.z);
        for (let j = 0; j < numberOfStripes; j++) {
            let stripeA = Vector3.lerp(bumperFullOutsideA, bumperFullOutsideB, j / numberOfStripes);
            let stripeB = Vector3.lerp(bumperFullOutsideA, bumperFullOutsideB, 1 / numberOfStripes + j / numberOfStripes);
            let stripeC = Vector3.lerp(b, c, 1 / numberOfStripes + j / numberOfStripes);
            let stripeD = Vector3.lerp(b, c, j / numberOfStripes);
            let stripeColor = Color.RED();
            if (j % 2 == 0)
                stripeColor = Color.WHITE();
            trackBumperMesh.convertQuadToTrisAndAddThem(stripeA, stripeB, stripeC, stripeD, stripeColor);
            trackSegments[i].outsideBarrierMesh.convertQuadToTrisAndAddThem(stripeA, stripeB, stripeC, stripeD, stripeColor);
        }
    }


    trackFinishLineMesh = new Mesh();
    let finishLineA = Vector3.lerp(trackPoints[0].pos, trackPoints[0].nextPoint.pos, .2);
    let finishLineB = Vector3.lerp(trackPoints[0].outsidePoint, trackPoints[0].nextPoint.outsidePoint, .2);
    let finishLineC = Vector3.lerp(trackPoints[0].outsidePoint, trackPoints[0].previousPoint.outsidePoint, .2);
    let finishLineD = Vector3.lerp(trackPoints[0].pos, trackPoints[0].previousPoint.pos, .2);
    finishLineA.y -= .1;
    finishLineB.y -= .1;
    finishLineC.y -= .1;
    finishLineD.y -= .1;
    for (let i = 0; i < 8; i++) {
        let color = Color.WHITE();
        if (i % 2 == 0)
            color = new Color();
        trackFinishLineMesh.convertQuadToTrisAndAddThem(Vector3.lerp(finishLineA, finishLineB, i / 8),
            Vector3.lerp(finishLineA, finishLineB, 1 / 8 + i / 8),
            Vector3.lerp(trackPoints[0].pos, trackPoints[0].outsidePoint, 1 / 8 + i / 8),
            Vector3.lerp(trackPoints[0].pos, trackPoints[0].outsidePoint, i / 8),
            color);
    }

    for (let i = 0; i < 8; i++) {
        let color = new Color();
        if (i % 2 == 0)
            color = Color.WHITE();
        trackFinishLineMesh.convertQuadToTrisAndAddThem(Vector3.lerp(trackPoints[0].pos, trackPoints[0].outsidePoint, i / 8),
            Vector3.lerp(trackPoints[0].pos, trackPoints[0].outsidePoint, 1 / 8 + i / 8),
            Vector3.lerp(finishLineD, finishLineC, 1 / 8 + i / 8),
            Vector3.lerp(finishLineD, finishLineC, i / 8),
            color);
    }

    raceTrack.addAndSortSegments(trackSegments);
    for (let i = 0; i < raceTrack.segments.length; i++) {
        if (i == 0) {
            raceTrack.segments[0].previousSegment = raceTrack.segments[raceTrack.segments.length - 1];
            raceTrack.segments[0].nextSegment = raceTrack.segments[1];
        }
        else if (i == trackPoints.length - 1) {
            raceTrack.segments[i].previousSegment = raceTrack.segments[raceTrack.segments.length - 2];
            raceTrack.segments[i].nextSegment = raceTrack.segments[0];
        }
        else {
            raceTrack.segments[i].previousSegment = raceTrack.segments[i - 1];
            raceTrack.segments[i].nextSegment = raceTrack.segments[i + 1];
        }
    }
    raceTrack.calculateLengthAndPercentages();
    highlightCycleTimer = 0;
    raceTrack.highlightNextSegment();
    raceTrack.mesh = trackMesh;
    raceTrack.model = trackModel;
}

function startRace() {
    raceTrack.resetTrack();
    setGameState(4);
    playerCar = new Car(carMesh);
    raceTrack.cars.push(playerCar);
    raceTrack.placeCarsOnTrack();
    camera.rot = new Vector3(0, 0, 0);
    camera.rotPitch(-32);
    trackModel.scale = new Vector3(1, 1, 1);
    trackModel.rot = new Vector3(0, 0, 0);
    trackBumperModel.scale = new Vector3(1, 1, 1);
    trackBumperModel.rot = new Vector3(0, 0, 0);
    trackFinishLineModel.scale = new Vector3(1, 1, 1);
    trackFinishLineModel.rot = new Vector3(0, 0, 0);
    raceTrack.resetColors();
    previewingTrack = false;
}

function updateLoop() {
    // #1 - Calculate "delta time"
    let dt = 1 / app.ticker.FPS;
    if (dt > 1 / 12) dt = 1 / 12;

    //reset our rendering objects
    render.clear();
    clearRenderBuffer();
    clearDepthBuffer();

    mousePosition = app.renderer.plugins.interaction.mouse.global;

    steeringWheel.update(dt);
    if (gameState == 0) {
        displayCarModel.pos = new Vector3(0, 0, 0);
        camera.pos = new Vector3(0, -27, -80);
        camera.rot = new Vector3(rad(-14), 0, 0);
        camera.fov = 90;
        displayCarModel.rotYaw(dt * -30);
        rasterizer.drawModel(displayCarModel);
        bgMenuNear.tilePosition.x -= dt * 70;
        bgMenuFar.tilePosition.x -= dt * 40;
        bgMenuSky.tilePosition.x -= dt * 20;
    } else if (gameState == 1) {
        camera.pos = new Vector3(0, -27, -80);
        camera.rot = new Vector3(rad(-14), 0, 0);
        camera.fov = 90;
        displayCarModel.rotYaw(dt * -30);
        bgMenuNear.tilePosition.x -= dt * 70;
        bgMenuFar.tilePosition.x -= dt * 40;
        bgMenuSky.tilePosition.x -= dt * 20;
    } else if (gameState == 2) {
        displayCarModel.pos.x = 17;
        camera.pos = new Vector3(0, -27, -80);
        camera.rot = new Vector3(rad(-14), 0, 0);
        camera.fov = 90;
        displayCarModel.rotYaw(dt * -30);
        bgMenuNear.tilePosition.x -= dt * 70;
        bgMenuFar.tilePosition.x -= dt * 40;
        bgMenuSky.tilePosition.x -= dt * 20;
        rasterizer.drawModel(displayCarModel);
        rasterizer.drawModel(displayTrackModel);
    } else if (gameState == 3) {
        camera.pos = new Vector3(0, -60, -140);
        camera.rot = new Vector3(rad(-25), 0, 0);
        camera.fov = 90;
        trackModel.scale = new Vector3(.0625, .25, .0625);
        trackBumperModel.scale = new Vector3(.0625, .25, .0625);
        trackFinishLineModel.scale = new Vector3(.0625, .25, .0625);
        trackModel.rotYaw(dt * 30);
        trackBumperModel.rotYaw(dt * 30);
        trackFinishLineModel.rotYaw(dt * 30);
        bgMenuNear.tilePosition.x -= dt * 70;
        bgMenuFar.tilePosition.x -= dt * 40;
        bgMenuSky.tilePosition.x -= dt * 20;
        highlightCycleTimer += dt;
        if (highlightCycleTimer > .05) {
            highlightCycleTimer = 0;
            raceTrack.highlightNextSegment();
        }
        rasterizer.drawModel(trackModel);
        rasterizer.drawModel(trackBumperModel);
        rasterizer.drawModel(trackFinishLineModel);
    } else if (gameState == 4) {
        raceTrack.update(dt);
        if (keysReleased["27"] && !keysHeld["27"]) {
            setGameState(5);
        }
        let carForwardDirection = new Vector2(Math.sin(rad(playerCar.carYawRot)), Math.cos(rad(playerCar.carYawRot)));
        camera.pos = new Vector3(playerCar.pos.x, playerCar.pos.y - 40, playerCar.pos.z);
        if (playerCar.mirror) {
            camera.pos.x = playerCar.pos.x + 120 * carForwardDirection.x;
            camera.pos.z = playerCar.pos.z + 120 * carForwardDirection.y;
            camera.rot = new Vector3(rad(-10), rad(180 + playerCar.carYawRot), 0);
        } else {
            camera.pos.x = playerCar.pos.x - 120 * carForwardDirection.x;
            camera.pos.z = playerCar.pos.z - 120 * carForwardDirection.y;
            camera.rot = new Vector3(rad(-10), rad(playerCar.carYawRot), 0);
        }

        raceTrack.drawOptimizedTrack(rasterizer);
        rasterizer.drawModel(playerCar);
        if (playerCar.segmentData.segment.index < 2 || playerCar.segmentData.segment.index > raceTrack.segments.length - 6)
            rasterizer.drawModel(trackFinishLineModel);
        bgEvening.tilePosition.x = -16 * playerCar.carYawRot;
    }
    else if (gameState == 5) {
        if (keysReleased["27"] && !keysHeld["27"]) {
            setGameState(4);
        }
        let carForwardDirection = new Vector2(Math.sin(rad(playerCar.carYawRot)), Math.cos(rad(playerCar.carYawRot)));
        camera.pos = new Vector3(playerCar.pos.x, playerCar.pos.y - 40, playerCar.pos.z);
        if (playerCar.mirror) {
            camera.pos.x = playerCar.pos.x + 120 * carForwardDirection.x;
            camera.pos.z = playerCar.pos.z + 120 * carForwardDirection.y;
            camera.rot = new Vector3(rad(-10), rad(180 + playerCar.carYawRot), 0);
        } else {
            camera.pos.x = playerCar.pos.x - 120 * carForwardDirection.x;
            camera.pos.z = playerCar.pos.z - 120 * carForwardDirection.y;
            camera.rot = new Vector3(rad(-10), rad(playerCar.carYawRot), 0);
        }

        raceTrack.drawOptimizedTrack(rasterizer);
        rasterizer.drawModel(playerCar);
        if (playerCar.segmentData.segment.index < 2 || playerCar.segmentData.segment.index > raceTrack.segments.length - 6)
            rasterizer.drawModel(trackFinishLineModel);
        bgEvening.tilePosition.x = -16 * playerCar.carYawRot;
    }
    else if (gameState == 6) {
        let carForwardDirection = new Vector2(Math.sin(rad(playerCar.carYawRot)), Math.cos(rad(playerCar.carYawRot)));
        camera.pos = new Vector3(playerCar.pos.x, playerCar.pos.y - 40, playerCar.pos.z);
        if (playerCar.mirror) {
            camera.pos.x = playerCar.pos.x + 120 * carForwardDirection.x;
            camera.pos.z = playerCar.pos.z + 120 * carForwardDirection.y;
            camera.rot = new Vector3(rad(-10), rad(180 + playerCar.carYawRot), 0);
        } else {
            camera.pos.x = playerCar.pos.x - 120 * carForwardDirection.x;
            camera.pos.z = playerCar.pos.z - 120 * carForwardDirection.y;
            camera.rot = new Vector3(rad(-10), rad(playerCar.carYawRot), 0);
        }

        raceTrack.drawOptimizedTrack(rasterizer);
        rasterizer.drawModel(playerCar);
        if (playerCar.segmentData.segment.index < 2 || playerCar.segmentData.segment.index > raceTrack.segments.length - 6)
            rasterizer.drawModel(trackFinishLineModel);
        bgEvening.tilePosition.x = -16 * playerCar.carYawRot;
    }

    for (let y = 0; y < inGameResHeight; y++) {
        for (let x = 0; x < inGameResWidth; x++) {
            if (renderBuffer[x][y] != null) {
                render.beginFill(renderBuffer[x][y].toHex(), 1);
                render.drawRect(x * resScale, y * resScale, resScale, resScale);
                render.endFill();
            }
        }
    }

    keysReleased = [];
}

function keysDown(e) {
    keysHeld[e.keyCode] = true;
    keysUp[e.keyCode] = false;
}

function keysUp(e) {
    keysHeld[e.keyCode] = false;
    keysReleased[e.keyCode] = true;
}

//draws a pixel on the screen depending on the current depth of that pixel
function drawPixelOnScreenWithDepth(color = new Color(), x = 0, y = 0, depth = 0) {
    // if the new pixe lis not within the depth range, dont draw it
    if (depth < 0 || depth >= 1) {
        return;
    }

    //if its inside the screen resolution
    if (x >= 0 && x < inGameResWidth && y >= 0 && y < inGameResHeight) {
        //and its depth is closer to the camera than the current pixel depth is
        if (depthBuffer[x][y] > depth) {
            //draw it and store that depth!
            renderBuffer[x][y] = color;
            depthBuffer[x][y] = depth;
        }

    }
}

//resets our array of pixel colors back to black
function clearRenderBuffer() {
    renderBuffer = [];
    for (let x = 0; x < inGameResWidth; x++) {
        renderBuffer[x] = [];
        for (let y = 0; y < inGameResHeight; y++) {
            renderBuffer[x][y] = null;
        }
    }
}

//resets our array of depth values back to the max value
function clearDepthBuffer() {
    depthBuffer = [];
    for (let x = 0; x < inGameResWidth; x++) {
        depthBuffer[x] = [];
        for (let y = 0; y < inGameResHeight; y++) {
            depthBuffer[x][y] = 1;
        }
    }
}

function createBg(texture, scene) {
    let tiling = new PIXI.TilingSprite(texture, 1024, 576);
    tiling.position.set(0, 0);
    scene.addChild(tiling);

    return tiling;
}
