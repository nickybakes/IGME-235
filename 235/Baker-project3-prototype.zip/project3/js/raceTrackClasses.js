class TrackPoint {
    previousPoint;
    nextPoint;
    pos;
    //insidePoint;
    outsidePoint;
    //half the width of the track, similar to the radius of a circle
    widthHalf;
    constructor(x = 0, y = 0, z = 0, widthHalf = 4) {
        this.pos = new Vector3(x, heightMap.getHeight(new Vector2(x, z)), z);
        this.widthHalf = widthHalf;
    }

    // getInsidePoint() {
    //     let beforePoint = this.previousPoint.pos;
    //     let afterPoint = this.nextPoint.pos;
    //     beforePoint = beforePoint.toVector2XZ();
    //     afterPoint = afterPoint.toVector2XZ();
    //     let pos2 = this.pos.toVector2XZ();
    //     let normalDirection = Vector2.subtract(afterPoint, beforePoint).perpCCW().getNormal();
    //     let insidePoint = Vector2.add(pos2, Vector2.multiply(normalDirection, this.widthHalf));

    //     insidePoint = new Vector3(insidePoint.x, this.pos.y, insidePoint.y);
    //     this.insidePoint = insidePoint;
    //     return insidePoint;
    // }

    getOutsidePoint() {
        let beforePoint = this.previousPoint.pos;
        let afterPoint = this.nextPoint.pos;
        beforePoint = beforePoint.toVector2XZ();
        afterPoint = afterPoint.toVector2XZ();
        let pos2 = this.pos.toVector2XZ();

        let normalDirection = Vector2.subtract(afterPoint, beforePoint).perpCW().getNormal();
        let outsidePoint = Vector2.add(pos2, Vector2.multiply(normalDirection, this.widthHalf));

        outsidePoint = new Vector3(outsidePoint.x, heightMap.getHeight(new Vector2(outsidePoint.x, outsidePoint.y)), outsidePoint.y);
        this.outsidePoint = outsidePoint;
        return outsidePoint;
    }
}

//represents a very simple height map that is used to add height variation to the track
class HeightMap extends Matrix3 {
    constructor() {
        super();
        this.randomize();
    }

    randomize() {
        this.a1 = Math.random();
        this.a3 = Math.random();
        this.c1 = Math.random();
        this.c3 = Math.random();
        this.a2 = lerp(this.a1, this.a3, lerp(.1, .95, Math.random()));
        this.b1 = lerp(this.a1, this.c1, lerp(.1, .95, Math.random()));
        this.b3 = lerp(this.a3, this.c3, lerp(.1, .95, Math.random()));
        this.b2 = Math.random();
        this.c2 = lerp(this.c1, this.c3, lerp(.1, .95, Math.random()));
    }

    getHeight(point) {
        point = new Vector2(point.x / mapWidth, point.y / mapLength);
        if (point.x < 0) {
            //1st quadrant
            if (point.y >= 0) {
                let leftValue = lerp(this.b1, this.a1, point.y);
                let rightValue = lerp(this.b2, this.a2, point.y);
                return mapHeight * (lerp(rightValue, leftValue, -1 * point.x) - .5);
            }
            //4th quadrant
            else {
                let leftValue = lerp(this.b1, this.c1, -1 * point.y);
                let rightValue = lerp(this.b2, this.c2, -1 * point.y);
                return mapHeight * (lerp(rightValue, leftValue, -1 * point.x) - .5);
            }
        }
        else {
            //2nd quadrant
            if (point.y >= 0) {
                let leftValue = lerp(this.b2, this.a2, point.y);
                let rightValue = lerp(this.b3, this.a3, point.y);
                return mapHeight * (lerp(rightValue, leftValue, point.x) - .5);
            }
            //3rd quadrant
            else {
                let leftValue = lerp(this.b2, this.c2, -1 * point.y);
                let rightValue = lerp(this.b3, this.c3, -1 * point.y);
                return mapHeight * (lerp(rightValue, leftValue, point.x) - .5);
            }
        }
    }
}

class TrackSegment {
    //the verts that make up this segment
    a; b; c; d;
    tri1; tri2;
    insideBarrierMesh;
    outsideBarrierMesh;
    point1; point2;
    previousSegment;
    nextSegment;
    length;
    slopeVector;
    dotSlope;
    completionPercentageStart;
    completionPercentageFull;
    index;
    //the optimal yaw rotation of a car driving forward in this segment
    forwardYawRot;
    //the pitch the car should be at when on this segment
    forwardPitchRot;
    //the mesh tris that make up this segment
    constructor(a, b, c, d, tri1, tri2, point1, point2, index) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.tri1 = tri1;
        this.tri2 = tri2;
        this.insideBarrierMesh = new Mesh();
        this.outsideBarrierMesh = new Mesh();
        this.point1 = point1;
        this.point2 = point2;
        this.index = index;
        this.length = Vector2.dist(this.point1.pos.toVector2XZ(), this.point2.pos.toVector2XZ());
        this.slopeVector = Vector2.subtract(this.point2.pos.toVector2XZ(), this.point1.pos.toVector2XZ());
        this.dotSlope = Vector2.dot(this.slopeVector, this.slopeVector);
        this.completionPercentageStart = 0;


        //i was having trouble calculating the forward yaw rotation of the segments using ArcTan,
        //as ArcTan is limited to -90 to 90 and i needed a full 360.
        //so instead i creat 2 vectors, one is the forward vector of the segment, one points in every angle o to -360.
        //if they point in the same general direction (their dot product is close to 1), then that angle must be the forward angle!
        let midLine = Vector2.subtract(Vector2.lerp(a.toVector2XZ(), b.toVector2XZ(), .5), Vector2.lerp(d.toVector2XZ(), c.toVector2XZ(), .5)).getNormal();
        for (let i = 0; i > -360; i--) {
            if (Vector2.dot(midLine, new Vector2(Math.sin(rad(i)), Math.cos(rad(i)))) > .98) {
                this.forwardYawRot = i;
                break;
            }
        }
        // let forwardYawRotAD = deg(Math.atan(Vector2.subtract(a.toVector2XZ(), d.toVector2XZ()).getNormal().x / Vector2.subtract(a.toVector2XZ(), d.toVector2XZ()).getNormal().y));
        // let forwardYawRotBC = deg(Math.atan(Vector2.subtract(b.toVector2XZ(), c.toVector2XZ()).getNormal().x / Vector2.subtract(b.toVector2XZ(), c.toVector2XZ()).getNormal().y));
        // let forwardDeg = lerp(forwardYawRotAD, forwardYawRotBC, .5);
        // if (lerp(Vector2.subtract(a.toVector2XZ(), d.toVector2XZ()).getNormal().x, Vector2.subtract(b.toVector2XZ(), c.toVector2XZ()).getNormal().x, .5) < 0) {
        //     console.log(index + ":x " + forwardDeg);
        //     forwardDeg -= 180;
        // } else if (Vector2.subtract(a.toVector2XZ(), d.toVector2XZ()).getNormal().y < 0) {
        //     console.log(index + ":y " + forwardDeg);
        //     forwardDeg += 360;
        // }
        // this.forwardYawRot = forwardDeg;

        let forwardPitchRotAD = deg(Math.asin(Vector3.subtract(d, a).getNormal().y));
        let forwardPitchRotBC = deg(Math.asin(Vector3.subtract(c, b).getNormal().y));
        this.forwardPitchRot = lerp(forwardPitchRotAD, forwardPitchRotBC, .5);
    }

    setMeshColor(color) {
        this.tri1.color = color;
        this.tri2.color = color;
    }

    // getInterpolatedPoint2D(x = 0, y = 0) {
    //     let leftLine = Vector2.lerp(this.d, this.a, y);
    //     let rightLine = Vector2.lerp(this.c, this.b, y);
    //     return Vector2.lerp(leftLine, rightLine, x);
    // }
}

class RaceTrack {
    model;
    mesh;
    segments;
    segmentsQuad1;
    segmentsQuad2;
    segmentsQuad3;
    segmentsQuad4;
    highlightedTrackSegmentIndex;
    trackLength;
    fullLength;
    raceStarted;
    countDownTime;
    cars;

    constructor() {
        this.segments = [];
        this.segmentsQuad1 = [];
        this.segmentsQuad2 = [];
        this.segmentsQuad3 = [];
        this.segmentsQuad4 = [];
        this.cars = [];
        this.quadsPercentageMaxMins = [];
        this.highlightedTrackSegmentIndex = -1;
        this.raceStarted = false;
        this.countDownTime = 3;
        lapAlertLabel.text = "";
        wrongWayAlertLabel.text = "";
    }

    resetTrack() {
        this.cars = [];
        this.highlightedTrackSegmentIndex = -1;
        this.raceStarted = false;
        this.countDownTime = 3;
        lapAlertLabel.text = "";
        wrongWayAlertLabel.text = "";
    }

    placeCarsOnTrack() {
        for (let i = 0; i < this.cars.length; i++) {
            let position = this.trackLocationToPoint(new Vector2(.5, .96));
            this.cars[i].pos = new Vector3(position.x, 0, position.y);
            let segmentData = this.getSegmentDataPointIsIn(this.cars[i].pos.toVector2XZ());
            this.cars[i].carYawRot = this.segments[this.segments.length - 1].forwardYawRot;
            this.cars[i].rot.y = rad(this.cars[i].carYawRot);
        }
    }

    //takes track segments and sorts them based on the quadrant of the graph they are in
    //this means when we are searching for a segment to determine which segment a point is in, 
    //we can immediately narrow it down to segments in a specific quadrant
    addAndSortSegments(trackSegments) {
        this.segments = trackSegments;
        //sorts them into respective quads
        for (let i = 0; i < trackSegments.length; i++) {
            let verts = [trackSegments[i].a.toVector2XZ(), trackSegments[i].b.toVector2XZ(), trackSegments[i].c.toVector2XZ(), trackSegments[i].d.toVector2XZ()];
            let quadsAddedTo = [false, false, false, false];
            for (let j = 0; j < 4; j++) {
                if (verts[j].x >= 0 && verts[j].y >= 0 && !quadsAddedTo[0]) {
                    quadsAddedTo[0] = true;
                    this.segmentsQuad1.push(trackSegments[i]);
                }
                else if (verts[j].x < 0 && verts[j].y >= 0 && !quadsAddedTo[1]) {
                    quadsAddedTo[1] = true;
                    this.segmentsQuad2.push(trackSegments[i]);
                }
                else if (verts[j].x < 0 && verts[j].y < 0 && !quadsAddedTo[2]) {
                    quadsAddedTo[2] = true;
                    this.segmentsQuad3.push(trackSegments[i]);
                }
                else if (verts[j].x >= 0 && verts[j].y < 0 && !quadsAddedTo[3]) {
                    quadsAddedTo[3] = true;
                    this.segmentsQuad4.push(trackSegments[i]);
                }
            }
        }
    }

    calculateLengthAndPercentages() {
        this.fullLength = 0;
        for (let i = 0; i < this.segments.length; i++) {
            this.fullLength += this.segments[i].length;
        }
        let completionPercentage = 0;
        for (let i = 1; i < this.segments.length; i++) {
            this.segments[i].completionPercentageStart = completionPercentage + this.segments[i].length / this.fullLength;
            completionPercentage = this.segments[i].completionPercentageStart;
        }
        for (let i = 0; i < this.segments.length; i++) {
            if (i == this.segments.length - 1) {
                this.segments[i].completionPercentageFull = 1 - this.segments[i].completionPercentageStart;
            } else {
                this.segments[i].completionPercentageFull = this.segments[i].nextSegment.completionPercentageStart - this.segments[i].completionPercentageStart;
            }
        }

    }

    update(dt) {
        for (let i = 0; i < this.cars.length; i++) {
            let segmentCarIsIn = this.getSegmentDataPointIsIn(this.cars[i].pos.toVector2XZ());
            if (segmentCarIsIn == undefined || segmentCarIsIn == null) {
                segmentCarIsIn = this.cars[i].segmentData;
                if (segmentCarIsIn.uv.x < 0)
                    segmentCarIsIn.uv.x = -2;
                else
                    segmentCarIsIn.uv.x = 2;
            }
            this.cars[i].setSegmentData(segmentCarIsIn);
            this.cars[i].trackLocation = this.pointToTrackLocation(this.cars[i].pos.toVector2XZ(), this.cars[i].segmentData);
        }

        if (!this.raceStarted) {
            if (this.countDownTime == 3) {
                for (let i = 0; i < this.cars.length; i++) {
                    this.cars[i].update(dt);
                }
            }
            this.countDownTime -= dt;
            countDownLabel.text = parseInt(this.countDownTime + 1);
            if (this.countDownTime <= 0) {
                countDownLabel.text = "GO!"
                this.raceStarted = true;
            }
        } else {
            if (this.countDownTime > -.75) {
                this.countDownTime -= dt;
                countDownLabel.text = "GO!"
            } else {
                countDownLabel.text = "";
            }
            // get the places of each car in the race
            // for (let i = 0; i < this.cars.length; i++) {
            //     this.cars[i].placeInRace = this.cars.length + 1;
            //     for (let j = 0; j < this.cars.length; j++) {
            //         if (i != j && this.cars[i].getCompletionPercentage() > this.cars[j].getCompletionPercentage()) {
            //             this.cars[i].placeInRace--;
            //         }
            //     }
            // }

            for (let i = 0; i < this.cars.length; i++) {
                this.cars[i].update(dt);
            }
        }

    }

    //this method only draws the track segments closest to the player
    drawOptimizedTrack(rasterizer) {
        let renderDist = 6;
        let segmentToDraw = playerCar.segmentData.segment.previousSegment;
        for (let i = 0; i < renderDist; i++) {
            //segmentToDraw.setMeshColor(new Color(40 + 40 * (clamp(i, 2, renderDist) / renderDist), 40 + 40 * (clamp(i, 2, renderDist) / renderDist), 40 + 40 * (clamp(i, 2, renderDist) / renderDist)));
            rasterizer.drawTri(segmentToDraw.tri1);
            rasterizer.drawTri(segmentToDraw.tri2);
            for (let j = 0; j < segmentToDraw.insideBarrierMesh.tris.length; j++) {
                rasterizer.drawTri(segmentToDraw.insideBarrierMesh.tris[j], false);
                rasterizer.drawTri(segmentToDraw.outsideBarrierMesh.tris[j], false);
            }
            segmentToDraw = segmentToDraw.nextSegment;
        }
    }

    resetColors() {
        for (let i = 0; i < this.segments.length; i++) {
            this.segments[i].setMeshColor(new Color(50 + 60 * ((i + 1) / (trackPoints.length)), 50 + 60 * ((i + 1) / (trackPoints.length)), 50 + 60 * ((i + 1) / (trackPoints.length))));
        }
    }

    //1. find which mesh tri the point is inside/overtop
    //2. get the segment that tri is in
    //3. project the point onto the line of the segment
    //4. point's track location X equals length of projection vector/width of track at THAT 
    //part of of the line (lerp between widths of start and end points of that line)
    //5. point's track location Y equals the sum of completion percentages of all segments leading up to this one plus
    //a fraction of that line's completion percentage based on how far along the line the project was (0 thru 1)

    //returns an object that has the segment that the point is in, the tri that point is in, 
    //the barycentric coords of that point in that tri, and the bilinear coords of the point on that segment
    getSegmentDataPointIsIn(point) {
        //narrow down our segment search to just segments in one of the quadrants of the map
        let segmentsToSearch;
        if (point.x >= 0 && point.y >= 0) {
            segmentsToSearch = this.segmentsQuad1;
        }
        else if (point.x < 0 && point.y >= 0) {
            segmentsToSearch = this.segmentsQuad2;
        }
        else if (point.x < 0 && point.y < 0) {
            segmentsToSearch = this.segmentsQuad3;
        }
        else if (point.x >= 0 && point.y < 0) {
            segmentsToSearch = this.segmentsQuad4;
        }
        for (let i = 0; i < segmentsToSearch.length; i++) {
            //check the first tri of the segment
            let triBarycentricCoord = Vector2.triBarycentricCoords(segmentsToSearch[i].tri1.a.toVector2XZ(), segmentsToSearch[i].tri1.b.toVector2XZ(), segmentsToSearch[i].tri1.c.toVector2XZ(), point);
            if (triBarycentricCoord.x + triBarycentricCoord.y + triBarycentricCoord.z <= 1.2) {
                let bilinearCoord = Vector2.bilinearCoords(new Vector2(triBarycentricCoord.y, 1 - triBarycentricCoord.z));
                return { segment: segmentsToSearch[i], tri: segmentsToSearch[i].tri1, bary: triBarycentricCoord, uv: bilinearCoord };
            }
            //check the second tri of the segment
            triBarycentricCoord = Vector2.triBarycentricCoords(segmentsToSearch[i].tri2.b.toVector2XZ(), segmentsToSearch[i].tri2.c.toVector2XZ(), segmentsToSearch[i].tri2.a.toVector2XZ(), point);
            if (triBarycentricCoord.x + triBarycentricCoord.y + triBarycentricCoord.z <= 1.2) {
                let bilinearCoord = Vector2.bilinearCoords(new Vector2(1 - triBarycentricCoord.y, triBarycentricCoord.z));
                return { segment: segmentsToSearch[i], tri: segmentsToSearch[i].tri2, bary: triBarycentricCoord, uv: bilinearCoord };
            }
        }
    }

    pointToTrackLocation(point, segmentData) {
        if (segmentData == null)
            segmentData = this.getSegmentDataPointIsIn(point);

        let y = segmentData.segment.completionPercentageStart + (segmentData.uv.y * segmentData.segment.completionPercentageFull);

        return new Vector2(segmentData.uv.x, y);
    }

    //1. move segments to arrays, one for each quadrant
    //2. every frame, each car shall: find the tri/segment they are in by searching the quadrant array for the quadrant they are in
    //3. set their completion percentage, check for lap completion, etc
    //4. apply physics
    //5. move to inside the track
    //6. go thru each car and sort them by rank

    trackLocationToPoint(location) {
        let segmentLocationIsIn = this.segments[this.segments.length - 1];
        for (let i = 1; i < this.segments.length; i++) {
            if (location.y <= this.segments[i].completionPercentageStart) {
                segmentLocationIsIn = this.segments[i - 1];
                break
            }
        }
        // console.log(segmentLocationIsIn);
        let percentageY = (location.y - segmentLocationIsIn.completionPercentageStart) / segmentLocationIsIn.completionPercentageFull;
        return Vector2.bilinearInterp(new Vector2(location.x, percentageY), segmentLocationIsIn.a.toVector2XZ(), segmentLocationIsIn.b.toVector2XZ(),
            segmentLocationIsIn.c.toVector2XZ(), segmentLocationIsIn.d.toVector2XZ());
    }

    highlightNextSegment() {
        this.highlightedTrackSegmentIndex++;
        if (this.highlightedTrackSegmentIndex == this.segments.length)
            this.highlightedTrackSegmentIndex = 0;
        this.resetColors();
        for (let i = 0; i < 4; i++) {
            this.segments[moveIntoRange(this.highlightedTrackSegmentIndex - i, 0, this.segments.length)].setMeshColor(new Color(playerCarColor.red - i * 50, playerCarColor.green - i * 50, playerCarColor.blue - i * 50));
        }
    }
}

class Car extends Model {
    //having to deal with physics/control of the vehicle
    vel;
    acc;
    bumpVel;
    accMagnitude;
    speed;
    currentMaxSpeed = 500;
    maxSpeed = 500;
    minSpeed = -120;
    drifting;
    mirror;
    bumpSpeed;
    minBumpSpeed = 10;
    turnAmount;
    autoAccelerate;

    //keeping track of time spent on the track
    timeSpent = 0;
    lapTimes;
    numberOfLaps = 5;

    //vehicle properties
    currentMaxAccMagnitude = 11;
    maxAccMagnitude = 11;
    carYawRot;

    segmentData;
    trackLocation;
    lapCount;
    placeInRace;
    //to make sure the car has gone all the way around the track to count a lap
    //we keep track of which segments the player has entered.
    segmentsEntered = [];


    constructor(mesh) {
        super(0, 0, 0, 0, 0, 0, 2, 2, 2, mesh);
        this.lapCount = -1;
        this.segmentsEntered = [];
        this.vel = new Vector2();
        this.acc = new Vector2();
        this.carYawRot = 0;
        this.speed = 0;
        this.bumpSpeed = 0;
        this.turnAmount = 0;
        this.carYawRot = 0;
        this.autoAccelerate = false;
        this.timeSpent = 0;
        this.lapTimes = [];
        for (let i = 0; i < this.numberOfLaps; i++) {
            this.lapTimes.push(0);
        }
    }

    increaseLapCount() {
        this.lapCount++;
        if (this.lapCount + 1 < this.numberOfLaps) {
            //update hud element/play animation here
            lapAlertLabel.text = "LAP " + (this.lapCount + 1) + "/" + this.numberOfLaps;
        }
        else if (this.lapCount + 1 == this.numberOfLaps) {
            lapAlertLabel.text = "FINAL LAP!";
        }
        else if (this.lapCount + 1 > this.numberOfLaps) {
            //sort through our lap times to find the best lap
            let bestLap = 0;
            for (let i = 0; i < this.lapTimes.length; i++) {
                if (this.lapTimes[i] < this.lapTimes[bestLap]) {
                    bestLap = i;
                }
            }

            //set the HUD labels to the times, highlight the best one in yellow
            for (let i = 0; i < this.lapTimes.length; i++) {
                resultsLapTimeLabels[i].text = secondsToTimeString(this.lapTimes[i]);
                resultsLapNumberLabels[i].style = hudLabelStyleWhite;
                resultsLapTimeLabels[i].style = hudLabelStyleWhite;
                if (i == bestLap) {
                    resultsLapTimeLabels[i].style = hudLabelStyleYellow;
                    resultsLapNumberLabels[i].style = hudLabelStyleYellow;
                }
            }

            resultsTotalTimeLabel.text = secondsToTimeString(this.timeSpent);

            setGameState(6);
        }
    }

    setSegmentData(segmentData) {
        this.segmentData = segmentData;
        this.trackLocation = segmentData.uv;
        if (segmentData.segment.index == 0) {
            //at the start of the race
            if (this.lapCount == -1) {
                //just reset the lap counter when you first cross the finish line
                this.lapCount = 0;
            } else if (this.segmentsEntered[segmentData.segment.previousSegment.index] || this.segmentsEntered[segmentData.segment.previousSegment.previousSegment.index]) {
                this.increaseLapCount();
            }
            this.segmentsEntered = [];
            for (let i = 0; i < raceTrack.segments.length; i++) {
                this.segmentsEntered.push(false);
            }
            this.segmentsEntered[0] = true;
        } else if (this.lapCount != -1) {
            if (this.segmentsEntered[segmentData.segment.previousSegment.index] || this.segmentsEntered[segmentData.segment.previousSegment.previousSegment.index]) {
                this.segmentsEntered[segmentData.segment.index] = true;
            }
        }
    }

    getCompletionPercentage() {
        return this.lapCount + this.trackLocation.y;
    }

    update(dt) {
        timeLabel.text = secondsToTimeString(this.timeSpent);

        if (this.lapCount != -1 && this.lapCount < this.numberOfLaps) {
            this.timeSpent += dt;
            this.lapTimes[this.lapCount] += dt;
            if (this.lapTimes[this.lapCount] > 1) {
                lapAlertLabel.text = "";
            }
        }

        if (this.bumpSpeed >= this.minBumpSpeed) {
            speedLabel.text = parseInt(Math.abs(this.bumpSpeed / 8)) + " mph";
        } else {
            speedLabel.text = parseInt(Math.abs(this.speed / 8)) + " mph";
        }
        if (this.lapCount + 1 == 0) {
            lapCountLabel.text = "LAP 1/" + this.numberOfLaps;
        } else {
            lapCountLabel.text = "LAP " + (this.lapCount + 1) + "/" + this.numberOfLaps;
        }

        this.drifting = false;
        this.mirror = false;
        //W is gas
        //e is toggle auto-gas
        //space is drift
        //Shift is break
        if (this.autoAccelerate || keysHeld["87"]) {
            this.accMagnitude = this.currentMaxAccMagnitude;
        }
        if (keysReleased["69"] && !keysHeld["69"]) {
            this.autoAccelerate = !this.autoAccelerate;
        }
        if (keysHeld["81"]) {
            this.mirror = true;
        }
        if (keysHeld["16"] || keysHeld["83"]) {
            this.accMagnitude = -this.currentMaxAccMagnitude;
        }
        if (keysHeld["32"] && this.speed > 7 && this.bumpSpeed < this.minBumpSpeed) {
            this.drifting = true;
        }
        if (!this.autoAccelerate && !keysHeld["87"] && !keysHeld["83"] && !keysHeld["16"]) {
            this.accMagnitude = 0;
        }

        //get the amount the player is turning
        if (this.drifting) {
            this.turnAmount = lerp(this.turnAmount, Math.sign(mousePosition.x - sceneWidth / 2) * 1.25, 2 * dt);
            this.turnAmount = clamp(this.turnAmount, -1.25, 1.25);
        } else {
            let screenThird = sceneWidth / 3;
            if (mousePosition.x < screenThird) {
                this.turnAmount = lerp(this.turnAmount, (mousePosition.x - screenThird) / (screenThird), 2 * dt);
            } else if (mousePosition.x > screenThird && mousePosition.x < screenThird * 2) {
                this.turnAmount = 0;
            } else {
                this.turnAmount = lerp(this.turnAmount, (mousePosition.x - screenThird * 2) / (screenThird), 2 * dt);
            }
            this.turnAmount = clamp(this.turnAmount, -1, 1);
        }


        if (this.drifting) {
            this.currentMaxSpeed = this.maxSpeed + 100;
            this.currentMaxAccMagnitude = this.maxAccMagnitude + 40;
        } else {
            this.currentMaxSpeed = this.maxSpeed;
            this.currentMaxAccMagnitude = this.maxAccMagnitude;
        }

        this.speed += this.accMagnitude;
        this.speed = lerp(this.speed, clamp(this.speed, this.minSpeed, this.currentMaxSpeed), 20 * dt);
        this.speed = lerp(this.speed, 0, dt);

        //this.acc = (new Vector2(this.turnAmount, 1)).getNormal();
        this.acc = new Vector2(Math.sin(rad(this.carYawRot)), Math.cos(rad(this.carYawRot)));

        //this.acc = Vector2.multiply(this.acc, this.accMagnitude);

        //let speedSquared = this.vel.magnitudeSquared();
        if (this.drifting) {
            this.carYawRot += this.turnAmount * (this.speed) * dt * 1.2;
        } else {
            this.carYawRot += this.turnAmount * (this.speed) * dt;
        }

        if (this.bumpSpeed >= this.minBumpSpeed) {
            this.acc = Vector2.multiply(this.acc, .5);
        }

        if (this.speed != 0) {
            this.vel = Vector2.add(this.vel, this.acc).getNormal();
        }

        if (this.trackLocation.x <= .03) {
            let position = raceTrack.trackLocationToPoint(new Vector2(.1, this.trackLocation.y));
            this.pos.x = position.x;
            this.pos.z = position.y;
            let bounceDirection = Vector2.subtract(this.segmentData.segment.d.toVector2XZ(), this.segmentData.segment.a.toVector2XZ()).getNormal().perpCCW();
            this.bumpSpeed = this.speed / 2;
            this.vel = bounceDirection;
        }
        else if (this.trackLocation.x >= .97) {
            let position = raceTrack.trackLocationToPoint(new Vector2(.9, this.trackLocation.y));
            this.pos.x = position.x;
            this.pos.z = position.y;
            let bounceDirection = Vector2.subtract(this.segmentData.segment.c.toVector2XZ(), this.segmentData.segment.b.toVector2XZ()).getNormal().perpCW();
            this.bumpSpeed = this.speed / 2;
            this.vel = bounceDirection;
        }

        if (this.bumpSpeed >= this.minBumpSpeed) {
            this.pos.x += this.vel.x * this.bumpSpeed * dt;
            this.pos.z += this.vel.y * this.bumpSpeed * dt;
            this.bumpSpeed = lerp(this.bumpSpeed, 0, 6 * dt);
        } else {
            this.pos.x += this.vel.x * this.speed * dt;
            this.pos.z += this.vel.y * this.speed * dt;
        }

        //clamp speed to zero if its close enough
        if (this.speed < 1 && this.speed > -1) {
            this.speed = 0;
        }

        camera.fov = 75 + 15 * (this.speed / this.maxSpeed);

        //this.rot.y = rad(this.carYawRot - (Math.sign(this.carYawRot) * this.turnAmount * (this.speed / 2) * 1.2)/2);

        //rotate the car's yaw
        if (this.drifting) {
            this.rot.y = lerp(this.rot.y, rad(this.carYawRot - Math.sign(this.carYawRot) * this.turnAmount * (this.speed / 8) * 1.2), 20 * dt);
        } else {
            this.rot.y = lerp(this.rot.y, rad(this.carYawRot - Math.sign(this.carYawRot) * this.turnAmount * (this.speed / 8)), 20 * dt);
        }

        let a = new Vector2(Math.sin(rad(this.carYawRot)), Math.cos(rad(this.carYawRot)));
        let b = new Vector2(Math.sin(rad(this.segmentData.segment.forwardYawRot)), Math.cos(rad(this.segmentData.segment.forwardYawRot)));
        if (Vector2.dot(a, b) > -.4) {
            //rotate the car's pitch so it looks like it is going up/down hills
            this.rot.x = lerp(this.rot.x, rad(this.segmentData.segment.forwardPitchRot), 5 * dt);
            wrongWayAlertLabel.text = "";
        } else {
            //rotate the car's pitch so it looks like it is going up/down hills
            this.rot.x = lerp(this.rot.x, -rad(this.segmentData.segment.forwardPitchRot), 5 * dt);
            wrongWayAlertLabel.text = "WRONG WAY!";
        }



        let yPos = bilinearInterp(this.segmentData.uv, this.segmentData.segment.a.y, this.segmentData.segment.b.y, this.segmentData.segment.c.y, this.segmentData.segment.d.y);
        this.pos.y = yPos;
    }

    pressGas() {
        accMagnitude = maxAccMagnitude;
    }

    pressBreaks() {

    }

}
